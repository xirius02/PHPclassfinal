if ($("#input").is('empty')) {
console.log('empty');
} else {
console.log('not empty');
}