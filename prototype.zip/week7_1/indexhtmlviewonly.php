<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
.tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top;}
.tg .tg-0lax{text-align:left;vertical-align:top;}
.tg td{border-radius: 25px;}
</style>
<head>
        <meta charset="UTF-8">
        <title></title>
         <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-item nav-link"><span class="sr-only">Hello [Insert Name]</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-item nav-link" href="logout.php">logout<span class="sr-only"></span></a>
                    </li>
                </ul>
            </div>
            </nav>
    </head>
<link rel="stylesheet" type="text/css" href="style.css" href="style.css">
<html>
      <form method="post">
        <div class="">
        <div>
          <div style="text-align: center">
              <a href="createnew.php">Create New Project</a>
          </div>
        </div>
            <div>
                <table class="tg">
                <thead>
                    <tr>
                      <th class="tg-0pky">Project Name</th>
                      <th class="tg-0lax">Group Leader</th>
                      <th class="tg-0lax">Creation Date</th>
                      <th class="tg-0lax">Worked Time</th>
                      <th class="tg-0lax" style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
            
                    <tr>
                        <td class="tg-0lax">Name</td>
                      <td class="tg-0lax">Group Leader</td>
                      <td class="tg-0lax">Creation Date</td>
                      <td class="tg-0lax">worked time</td>
                      <td><a class="btn btn-warning">Update</a><a>  </a><a class="btn btn-danger">Delete</a></td>
                    </tr>
            
                </tbody>
                  </table>
          </div>
        </div>
    </form>
</html>
